//
//  WelcomeViewController.swift
//  NextURacing
//
//  Created by Amairani González on 12/2/18.
//  Copyright © 2017 NextU. All rights reserved.
//

import UIKit
import GoogleMobileAds

class WelcomeViewController: UIViewController, GADInterstitialDelegate {
    
    //MARK: IBOutlets
    @IBOutlet weak var bvBannerView: GADBannerView!
    @IBOutlet weak var lbVueltas: UILabel!
    @IBOutlet weak var lbNombre: UILabel!
    @IBOutlet weak var lcCarLeading: NSLayoutConstraint!
    
    //MARK: Properties
    let request = GADRequest()
    var interstitial: GADInterstitial!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //Se configura la publicidad
        self.configureAdMob()
        self.loadInterstitial()
    }
    
    override func viewDidAppear(animated: Bool) {
        super.viewDidAppear(animated)
        
        //Se carga la información de UserDefaults
        self.loadInfoFromUserDefaults()
        
    }
    
    override func viewDidDisappear(animated: Bool) {
        
        super.viewDidAppear(animated)
        
        //Se pone el auto en su lugar original
        self.lcCarLeading.constant = 20;
    }
    
    //Método para cargar la información desde UserDefaults
    private func loadInfoFromUserDefaults(){
        
        if let username = Util.getRegisteredUser() {
            
            self.lbNombre.text = username
            
        } else {
            
            self.showAlertForName()
            
        }
        
        let maxTurns = Util.getMaxRate()
        
        self.lbVueltas.text = "\(maxTurns)"
        
    }
    
    //Método para mostrar alerta con campo de texto
    private func showAlertForName(){
        
        let alert = UIAlertController(title: "NextU Racing",
                                      message: "Ingresa tu nombre de usuario",
                                      preferredStyle: .Alert)
        
        alert.addTextFieldWithConfigurationHandler { (textField) in
            
            textField.placeholder = "Unknown user"
            
        }
        
        let saveAction = UIAlertAction(title: "Guardar", style: .Default) { (action) in
            
            if let textField = alert.textFields?.first{
                
                if textField.text?.characters.count > 0{
                    
                    self.lbNombre.text = textField.text!
                    
                    Util.setRegisteredUser(self.lbNombre.text!)
                    
                } else{
                    
                    self.showAlertForName()
                    
                }
                
            }
            
        }
        
        let cancelAction = UIAlertAction(title: "Cancelar", style: .Destructive) { (action) in
            
            let defaults = NSUserDefaults.standardUserDefaults()
            
            defaults.setObject("GUEST", forKey: Constants.USERNAME)
            
            self.lbNombre.text = "GUEST"
            
        }
        
        alert.addAction(saveAction)
        alert.addAction(cancelAction)
        
        self.presentViewController(alert,
                                   animated: true,
                                   completion: nil)
    }
    
    //Método para configurar la publicidad
    private func configureAdMob(){
        
        self.request.testDevices = [kGADSimulatorID]
        self.bvBannerView.adUnitID = Constants.bannerID
        self.bvBannerView.rootViewController = self
        self.bvBannerView.loadRequest(self.request)
        
    }
    
    //Método para lanzar el juego
    @IBAction func didTapPlay(sender: UIButton) {
        
        self.lcCarLeading.constant = self.view.frame.width
        
        UIView.animateWithDuration(3, animations: {
            
            self.view.layoutIfNeeded()
            
        }) { (end) in
            
            self.showInterstitial()
            
        }
        
    }
    
    //Método para cargar y preparar el interstitial
    private func loadInterstitial(){
        
        let requestInterstitial = GADRequest()
        
        self.interstitial = GADInterstitial(adUnitID: Constants.interstitialID)
        self.interstitial.delegate = self
        
        requestInterstitial.testDevices = [kGADSimulatorID]
        
        interstitial.loadRequest(requestInterstitial)
        
    }
    
    //Método para mostrar la publicidad
    private func showInterstitial(){
        
        if self.interstitial.isReady {
            
            self.interstitial.presentFromRootViewController(self)
            
        } else {
            
            self.performSegueWithIdentifier("showGame",
                                            sender: nil)
            
        }
        
    }
    
    
    //MARK: GADInterstitialDelegate Methods
    
    func interstitialDidDismissScreen(ad: GADInterstitial) {
        
        self.performSegueWithIdentifier("showGame",
                                        sender: nil)
        
    }
    
    func interstitial(ad: GADInterstitial, didFailToReceiveAdWithError error: GADRequestError) {
        
        print("\(#function): \(error.localizedDescription)")
        
    }
    
}
