//
//  AdColonyTestViewController.swift
//  NextURacing
//
//  Created by Amairani González on 12/2/18.
//  Copyright © 2017 NextU. All rights reserved.
//

import UIKit

//Clase utilizada como "HUB" para poder mostrar los videos de AdColony
class AdColonyTestViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        NSNotificationCenter.defaultCenter().addObserver(self,
                                                         selector: #selector(AdColonyTestViewController.showAdColony(_:)),
                                                         name: Constants.showColonyNotification,
                                                         object: nil)
    }
    
    deinit{
        
        NSNotificationCenter.defaultCenter().removeObserver(self,
                                                            name: Constants.showColonyNotification,
                                                            object: nil)
    }
    
    //Método que se ejecuta al recibir la notificación para mostrar el video
    @objc private func showAdColony(notification:NSNotification){
        
        AdColonyManager.sharedInstance().showColonyVideo(self)
        
    }

}
