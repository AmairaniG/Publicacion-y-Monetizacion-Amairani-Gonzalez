//
//  AdColonyHeader.h
//  NextURacing
//
//  Created by Manuel Pérez on 4/2/17.
//  Copyright © 2017 NextU. All rights reserved.
//

#ifndef AdColonyHeader_h
#define AdColonyHeader_h

#import <AdColony/AdColony.h>
#import <Google/Analytics.h>

#endif /* AdColonyHeader_h */
