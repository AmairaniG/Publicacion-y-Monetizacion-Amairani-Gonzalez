//
//  AdColonyManager.swift
//  NextURacing
//
//  Created by Amairani González on 12/2/18.
//  Copyright © 2017 NextU. All rights reserved.
//

import Foundation

class AdColonyManager {
    
    //MARK: Singleton
    private static var instance:AdColonyManager?
    
    static func sharedInstance() -> AdColonyManager{
        
        if self.instance == nil{
            
            self.instance = AdColonyManager()
            
            self.instance!.startConfig()
            
        }
        
        return self.instance!
    }
    
    private init(){}
    
    //MARK: Properties
    private var adColonyInterstitial:AdColonyInterstitial?
    private var isReady:Bool!
    
    private func startConfig(){
        
        AdColony.configureWithAppID(Constants.addColonyID,
                                    zoneIDs: [Constants.zoneID],
                                    options: nil) { (zones) in
                                        
                                        self.requestInterstitial()
                                        
        }
    }
    
    private func requestInterstitial(){
        
        self.isReady = false
        AdColony.requestInterstitialInZone(Constants.zoneID,
                                           options: nil,
                                           success: { (interstitial) in
                                            
                                            //Para cuando se cierra el interstitial
                                            interstitial.setClose({
                                                
                                                self.adColonyInterstitial = nil
                                                self.requestInterstitial()
                                                
                                            })
                                            
                                            //Por si expira el interstitial
                                            interstitial.setExpire({
                                                
                                                self.adColonyInterstitial = nil
                                                self.requestInterstitial()
                                                
                                            })
                                            
                                            self.adColonyInterstitial = interstitial
                                            
                                            self.isReady = true
                                            
        }) { (error) in
            
            print("Error: \(error.localizedDescription)")
            
        }
    }
    
    func showColonyVideo(viewController:UIViewController){
        
        if let interstitial = self.adColonyInterstitial{
            
            if !interstitial.expired && self.isReady {
                
                interstitial.showWithPresentingViewController(viewController)
                
            }
            
        }
    }
    
}