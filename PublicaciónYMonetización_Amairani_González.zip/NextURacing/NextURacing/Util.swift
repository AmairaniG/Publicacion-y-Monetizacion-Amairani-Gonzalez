//
//  Util.swift
//  NextURacing
//
//  Created by Amairani González on 12/2/18.
//  Copyright © 2017 NextU. All rights reserved.
//

import Foundation

class Util{
    
    //Método para evaluar el puntaje más alto y definir si se ha roto la marca
    static func evaluateMax(newValue: Int){
        
        if newValue > getMaxRate() {
            
            let defaults = NSUserDefaults.standardUserDefaults()
            
            defaults.setInteger(newValue, forKey: Constants.MAX_RECORD)
            
            //Se registra en Google Analytics el resultado
            self.registerGoogleAnalytics(newValue)
            
        }
        
    }
    
    //Método para registrar cuando se supera el record
    private static func registerGoogleAnalytics(newValue: Int){
        
        let defaults = NSUserDefaults.standardUserDefaults()
        
        let username = defaults.stringForKey(Constants.USERNAME)
            
        let tracker = GAI.sharedInstance().defaultTracker
        
        let category = "Best User Laps"
        let action = "Best Laps"
        let label = "\(username!) - \(newValue)"
        
        let event = GAIDictionaryBuilder.createEventWithCategory(category,
                                                                 action: action,
                                                                 label: label,
                                                                 value: nil)
        
        tracker.send(event.build() as [NSObject:AnyObject])
        
    }
    
    //Método para obtener el record Máximo
    static func getMaxRate()-> Int{
        
        let defaults = NSUserDefaults.standardUserDefaults()
        
        let currentValue = defaults.integerForKey(Constants.MAX_RECORD)
        
        return currentValue
        
    }
    
    //Método para obtener el usuario registrado
    static func getRegisteredUser()-> String?{
        
        let defaults = NSUserDefaults.standardUserDefaults()
        
        let name = defaults.stringForKey(Constants.USERNAME)
        
        return name
        
    }
    
    //Método para registrar un nuevo usuario
    static func setRegisteredUser(username:String){
        
        let defaults = NSUserDefaults.standardUserDefaults()
        
        defaults.setObject(username, forKey: Constants.USERNAME)
        
    }
    
}