//
//  Util.swift
//  NextURacing
//
//  Created by Amairani González on 12/2/18.
//  Copyright © 2017 NextU. All rights reserved.
//

import Foundation

class Constants{
    
    static let USERNAME:String = "USERNAME"
    static let MAX_RECORD:String = "MAX_RECORD"
    
    static let bannerID:String = "ca-app-pub-9783557215362373/4981529647"
    static let interstitialID:String = "ca-app-pub-9783557215362373/6458262846"
    
    static let addColonyID:String = "appe6e873eff2f647a791"
    static let zoneID:String = "vza4f70728dd814c80a7"
    
    static let googleAnalyticsID:String = "UA-96670402-1"
    
    static let showColonyNotification:String = "showColonyNotification"
    
}
